# Gap Closure Note

**Episode:** 3 — The Cave  
**Act:** 4  
**Current Status:** GAP_FROM_REPO_AUDIT__RECOVERED_SPINE_NEEDS_FULL_SCRIPT

## Required Job
Turn this recovered spine into full script text.

## Recovered Spine

RECOVERED SPINE: The cost of keeping William alive rises. A water trip nearly exposes the hiding place. Mary Ann refuses to let panic make noise. The cave teaches the children that survival has no clean shape.

## Non-Negotiables

- Keep the five-act structure.
- Keep evidence lanes visible.
- Keep emotional pressure high without inventing proof.
- Account, not avenge.
