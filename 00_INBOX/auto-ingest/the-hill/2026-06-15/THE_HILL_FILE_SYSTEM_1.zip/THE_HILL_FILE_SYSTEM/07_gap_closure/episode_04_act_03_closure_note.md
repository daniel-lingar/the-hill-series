# Gap Closure Note

**Episode:** 4 — The Refugee Train  
**Act:** 3  
**Current Status:** GAP_FROM_REPO_AUDIT__RECOVERED_SPINE_NEEDS_FULL_SCRIPT

## Required Job
Turn this recovered spine into full script text.

## Recovered Spine

RECOVERED SPINE: The road becomes a second battlefield. Rain, wagons, hunger, and rumors reveal that flight is also a system of war.

## Non-Negotiables

- Keep the five-act structure.
- Keep evidence lanes visible.
- Keep emotional pressure high without inventing proof.
- Account, not avenge.
