# Gap Closure Note

**Episode:** 5 — Company K  
**Act:** 2  
**Current Status:** GAP_FROM_REPO_AUDIT__RECOVERED_SPINE_NEEDS_FULL_SCRIPT

## Required Job
Turn this recovered spine into full script text.

## Recovered Spine

RECOVERED SPINE: The roster cluster sharpens: Francis, William Riley, Pleasant, Lewis Cass, William Gordon, and John Turner. A family does not have to stand on one line to be targeted as one body.

## Non-Negotiables

- Keep the five-act structure.
- Keep evidence lanes visible.
- Keep emotional pressure high without inventing proof.
- Account, not avenge.
