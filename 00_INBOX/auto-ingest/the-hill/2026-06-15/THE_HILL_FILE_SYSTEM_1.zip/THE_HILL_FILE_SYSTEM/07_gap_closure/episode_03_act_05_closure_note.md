# Gap Closure Note

**Episode:** 3 — The Cave  
**Act:** 5  
**Current Status:** GAP_FROM_REPO_AUDIT__RECOVERED_SPINE_NEEDS_FULL_SCRIPT

## Required Job
Turn this recovered spine into full script text.

## Recovered Spine

RECOVERED SPINE: William weakens. He names guilt; Permelia refuses to let him confuse survival with sin. The act ends not with triumph but with the family still present: 'We're still here.'

## Non-Negotiables

- Keep the five-act structure.
- Keep evidence lanes visible.
- Keep emotional pressure high without inventing proof.
- Account, not avenge.
