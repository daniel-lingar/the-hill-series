# Gap Closure Note

**Episode:** 6 — Wash Middleton  
**Act:** 3  
**Current Status:** GAP_FROM_REPO_AUDIT__RECOVERED_SPINE_NEEDS_FULL_SCRIPT

## Required Job
Turn this recovered spine into full script text.

## Recovered Spine

RECOVERED SPINE: Wash and Fate watch the dance house. A soldier says the name too early. Fate nearly draws. Wash stops him: 'We have a maybe in a room full of people.' Not shooting is not nothing.

## Non-Negotiables

- Keep the five-act structure.
- Keep evidence lanes visible.
- Keep emotional pressure high without inventing proof.
- Account, not avenge.
