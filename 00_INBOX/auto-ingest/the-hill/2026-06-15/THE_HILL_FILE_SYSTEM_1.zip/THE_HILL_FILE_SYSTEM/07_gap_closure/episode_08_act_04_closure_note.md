# Gap Closure Note

**Episode:** 8 — The Inheritance  
**Act:** 4  
**Current Status:** GAP_FROM_REPO_AUDIT__RECOVERED_SPINE_NEEDS_FULL_SCRIPT

## Required Job
Turn this recovered spine into full script text.

## Recovered Spine

RECOVERED SPINE: The account leaves the room. Public challenge begins: why dig this up, whose side looks bad, whose name gets touched. Daniel answers with discipline: descendants are not defendants, but communities inherit responsibility to tell truth carefully.

## Non-Negotiables

- Keep the five-act structure.
- Keep evidence lanes visible.
- Keep emotional pressure high without inventing proof.
- Account, not avenge.
