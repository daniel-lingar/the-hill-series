# Gap Closure Note

**Episode:** 4 — The Refugee Train  
**Act:** 4  
**Current Status:** GAP_FROM_REPO_AUDIT__RECOVERED_SPINE_NEEDS_FULL_SCRIPT

## Required Job
Turn this recovered spine into full script text.

## Recovered Spine

RECOVERED SPINE: An armed stop forces the family to decide how much truth is safe. Children watch adults negotiate survival with partial names.

## Non-Negotiables

- Keep the five-act structure.
- Keep evidence lanes visible.
- Keep emotional pressure high without inventing proof.
- Account, not avenge.
