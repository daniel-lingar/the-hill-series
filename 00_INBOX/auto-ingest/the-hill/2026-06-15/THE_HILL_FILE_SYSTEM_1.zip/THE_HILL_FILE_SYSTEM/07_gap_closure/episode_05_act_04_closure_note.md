# Gap Closure Note

**Episode:** 5 — Company K  
**Act:** 4  
**Current Status:** GAP_FROM_REPO_AUDIT__RECOVERED_SPINE_NEEDS_FULL_SCRIPT

## Required Job
Turn this recovered spine into full script text.

## Recovered Spine

RECOVERED SPINE: John Turner wants action, but the file forces discipline. Names are sorted: Jess Wilson, Wash Middleton, Fate Arnold, local men, unknown. Heard is not nothing. Heard is not proof.

## Non-Negotiables

- Keep the five-act structure.
- Keep evidence lanes visible.
- Keep emotional pressure high without inventing proof.
- Account, not avenge.
