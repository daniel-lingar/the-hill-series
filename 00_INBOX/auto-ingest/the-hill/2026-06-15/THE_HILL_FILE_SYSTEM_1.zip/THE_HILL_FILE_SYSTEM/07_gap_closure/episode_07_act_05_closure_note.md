# Gap Closure Note

**Episode:** 7 — The Marriage  
**Act:** 5  
**Current Status:** GAP_FROM_REPO_AUDIT__RECOVERED_SPINE_NEEDS_FULL_SCRIPT

## Required Job
Turn this recovered spine into full script text.

## Recovered Spine

RECOVERED SPINE: The marriage ceremony becomes the structural climax. The record says married; the act shows what it cost. Marriage does not heal the war; it builds a room where the living can continue.

## Non-Negotiables

- Keep the five-act structure.
- Keep evidence lanes visible.
- Keep emotional pressure high without inventing proof.
- Account, not avenge.
