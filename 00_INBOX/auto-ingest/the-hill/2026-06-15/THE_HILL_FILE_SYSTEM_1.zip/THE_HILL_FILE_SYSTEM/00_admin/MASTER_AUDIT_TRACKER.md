# MASTER AUDIT TRACKER

This tracker is the retention layer for the project. It tells you what exists, what is missing, and where the missing work belongs.

| Episode | Title | Act | Status | Spine |
|---:|---|---:|---|---|
| 1 | Mulberry Township | 1 | DRAFT_SLOT_PRESENT | Land, creek, ridge, and homestead introduced as the first character. Spencer and William feel the pressure before the riders arrive. |
| 1 | Mulberry Township | 2 | DRAFT_SLOT_PRESENT | Ordinary neighbor contact becomes suspicious. The borrowed tool and road traffic start turning home into a watched place. |
| 1 | Mulberry Township | 3 | DRAFT_SLOT_PRESENT | Family routines keep moving under threat. The viewer learns that local war is intimate, not distant. |
| 1 | Mulberry Township | 4 | DRAFT_SLOT_PRESENT | The chicken dinner becomes the watched meal. Riders wait outside the frame while the house tries to act normal. |
| 1 | Mulberry Township | 5 | DRAFT_SLOT_PRESENT | The night closes with dread. The episode ends before the attack, with tomorrow hanging over the house. |
| 2 | The Chicken Dinner | 1 | DRAFT_SLOT_PRESENT | Morning after the watched dinner. Children, house, and potato field become the geometry of the attack. |
| 2 | The Chicken Dinner | 2 | DRAFT_SLOT_PRESENT | Riders close in. The children warn: 'Here they come, Grandpap.' Spencer recognizes them. |
| 2 | The Chicken Dinner | 3 | DRAFT_SLOT_PRESENT | Spencer is shot. William runs toward the trees/potato patch and falls. Violence is shown as rupture, not spectacle. |
| 2 | The Chicken Dinner | 4 | DRAFT_SLOT_PRESENT | The house is searched. Women survive by reading danger second by second. |
| 2 | The Chicken Dinner | 5 | DRAFT_SLOT_PRESENT | William is found breathing. The women carry him toward the cave. The cave is not safety; it is what they have left. |
| 3 | The Cave | 1 | DRAFT_SLOT_PRESENT | The cave becomes a living room, sickroom, and hiding place. Mary Ann tends William. Permelia guards the mouth. |
| 3 | The Cave | 2 | DRAFT_SLOT_PRESENT | Silence becomes labor. Children learn cave-silence. Care becomes resistance. |
| 3 | The Cave | 3 | DRAFT_SLOT_PRESENT | Water, breath, and food become dangerous. The family measures every move against riders and terrain. |
| 3 | The Cave | 4 | GAP_FROM_REPO_AUDIT__RECOVERED_SPINE_NEEDS_FULL_SCRIPT | RECOVERED SPINE: The cost of keeping William alive rises. A water trip nearly exposes the hiding place. Mary Ann refuses to let panic make noise. The cave teaches the children that survival has no clean shape. |
| 3 | The Cave | 5 | GAP_FROM_REPO_AUDIT__RECOVERED_SPINE_NEEDS_FULL_SCRIPT | RECOVERED SPINE: William weakens. He names guilt; Permelia refuses to let him confuse survival with sin. The act ends not with triumph but with the family still present: 'We're still here.' |
| 4 | The Refugee Train | 1 | DRAFT_SLOT_PRESENT | William dies in the cave. The family moves from hidden survival to forced motion. |
| 4 | The Refugee Train | 2 | GAP_FROM_REPO_AUDIT__RECOVERED_SPINE_NEEDS_FULL_SCRIPT | RECOVERED SPINE: The family joins the refugee road. Names are hidden, spoken carefully, and measured against strangers. |
| 4 | The Refugee Train | 3 | GAP_FROM_REPO_AUDIT__RECOVERED_SPINE_NEEDS_FULL_SCRIPT | RECOVERED SPINE: The road becomes a second battlefield. Rain, wagons, hunger, and rumors reveal that flight is also a system of war. |
| 4 | The Refugee Train | 4 | GAP_FROM_REPO_AUDIT__RECOVERED_SPINE_NEEDS_FULL_SCRIPT | RECOVERED SPINE: An armed stop forces the family to decide how much truth is safe. Children watch adults negotiate survival with partial names. |
| 4 | The Refugee Train | 5 | GAP_FROM_REPO_AUDIT__RECOVERED_SPINE_NEEDS_FULL_SCRIPT | RECOVERED SPINE: The ledger requires names. Company K enters not as background but as a pattern map. The episode ends on the call: 'Horner family?' |
| 5 | Company K | 1 | DRAFT_SLOT_PRESENT | Company K is established as the map of who was visible, targeted, absent, and remembered. |
| 5 | Company K | 2 | GAP_FROM_REPO_AUDIT__RECOVERED_SPINE_NEEDS_FULL_SCRIPT | RECOVERED SPINE: The roster cluster sharpens: Francis, William Riley, Pleasant, Lewis Cass, William Gordon, and John Turner. A family does not have to stand on one line to be targeted as one body. |
| 5 | Company K | 3 | DRAFT_SLOT_PRESENT | William Gordon Acord's secondary murder tradition enters as pattern evidence, carefully labeled and not over-proven. |
| 5 | Company K | 4 | GAP_FROM_REPO_AUDIT__RECOVERED_SPINE_NEEDS_FULL_SCRIPT | RECOVERED SPINE: John Turner wants action, but the file forces discipline. Names are sorted: Jess Wilson, Wash Middleton, Fate Arnold, local men, unknown. Heard is not nothing. Heard is not proof. |
| 5 | Company K | 5 | DRAFT_SLOT_PRESENT | John Turner writes the list. The paper gives the living a map. Maps can guide rescue or revenge. |
| 6 | Wash Middleton | 1 | DRAFT_SLOT_PRESENT | Wash Middleton enters as useful before safe. Modern frame warns that reprisal tradition must be handled carefully. |
| 6 | Wash Middleton | 2 | DRAFT_SLOT_PRESENT | Fate Arnold enters as pressure and danger. The dance-house lead is likely, not proven. Likely is discipline. |
| 6 | Wash Middleton | 3 | GAP_FROM_REPO_AUDIT__RECOVERED_SPINE_NEEDS_FULL_SCRIPT | RECOVERED SPINE: Wash and Fate watch the dance house. A soldier says the name too early. Fate nearly draws. Wash stops him: 'We have a maybe in a room full of people.' Not shooting is not nothing. |
| 6 | Wash Middleton | 4 | DRAFT_SLOT_PRESENT | Daylight complicates certainty. Almost is the cruelest category. Mary Ann gives the moral spine: knowing has to matter more than finishing. |
| 6 | Wash Middleton | 5 | DRAFT_SLOT_PRESENT | The armed party finally rides with official purpose, not clean revenge. John Turner goes as medical or follows anyway. |
| 7 | The Marriage | 1 | DRAFT_SLOT_PRESENT | After reprisal, no catharsis. John Turner washes blood and still has no finished answer. |
| 7 | The Marriage | 2 | DRAFT_SLOT_PRESENT | John Samuel grows into a man carrying HOUSE/CAVE/ROAD/BELIEVE. Amanda Hill enters as a person, not a symbol. |
| 7 | The Marriage | 3 | DRAFT_SLOT_PRESENT | The relationship becomes public. Amanda refuses to stand trial for a surname. Both names carry ghosts. |
| 7 | The Marriage | 4 | DRAFT_SLOT_PRESENT | Proposal/fence vows. Amanda says: 'Do not mistake me for peace.' John answers: 'You are Amanda.' |
| 7 | The Marriage | 5 | GAP_FROM_REPO_AUDIT__RECOVERED_SPINE_NEEDS_FULL_SCRIPT | RECOVERED SPINE: The marriage ceremony becomes the structural climax. The record says married; the act shows what it cost. Marriage does not heal the war; it builds a room where the living can continue. |
| 8 | The Inheritance | 1 | DRAFT_SLOT_PRESENT | Modern Daniel/Bret at cemetery and road. The inheritance is the question, not the answer. |
| 8 | The Inheritance | 2 | DRAFT_SLOT_PRESENT | Access, gates, land boundaries, and evidence boundaries. Write first. Account, not avenge. |
| 8 | The Inheritance | 3 | DRAFT_SLOT_PRESENT | The public dossier categories are built: Proven, Supported, Tradition, Question, Unknown. The page is alive, not final. |
| 8 | The Inheritance | 4 | GAP_FROM_REPO_AUDIT__RECOVERED_SPINE_NEEDS_FULL_SCRIPT | RECOVERED SPINE: The account leaves the room. Public challenge begins: why dig this up, whose side looks bad, whose name gets touched. Daniel answers with discipline: descendants are not defendants, but communities inherit responsibility to tell truth carefully. |
| 8 | The Inheritance | 5 | DRAFT_SLOT_PRESENT | The finale. Amanda is seen as a person, not a bridge. Daniel marks unresolved items and closes at the cemetery: 'As close as I can honestly stand.' |
