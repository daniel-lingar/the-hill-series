# Gap Closure Order

Close gaps in this order because each one feeds the next:

1. Episode 3 Acts 4–5 — finish cave survival and William's final state before the road.
2. Episode 4 Acts 2–5 — finish refugee-road transition and Company K bridge.
3. Episode 5 Acts 2 and 4 — finish roster logic and named-suspect discipline.
4. Episode 6 Act 3 — finish Wash/Fate restraint scene.
5. Episode 7 Act 5 — finish marriage as structural climax.
6. Episode 8 Act 4 — finish public-account/community-responsibility turn.

Rule: do not write revenge as payoff. Write account, consequence, and discipline.
