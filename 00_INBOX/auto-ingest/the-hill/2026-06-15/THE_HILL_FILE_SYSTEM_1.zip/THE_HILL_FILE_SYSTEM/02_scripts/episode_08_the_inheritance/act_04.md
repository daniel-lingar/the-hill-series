# Episode 8 — The Inheritance
## Act 4

**Status:** GAP_FROM_REPO_AUDIT__RECOVERED_SPINE_NEEDS_FULL_SCRIPT

## Canonical Spine

RECOVERED SPINE: The account leaves the room. Public challenge begins: why dig this up, whose side looks bad, whose name gets touched. Daniel answers with discipline: descendants are not defendants, but communities inherit responsibility to tell truth carefully.

## Script Body

[Place full scene-by-scene script text here. Keep this act inside the five-act structure.]

## Evidence Notes

- Mark historical claims as Proven / Supported / Tradition / Question / Unknown.
- Do not turn tradition into proof.
- Do not write violence as payoff.
