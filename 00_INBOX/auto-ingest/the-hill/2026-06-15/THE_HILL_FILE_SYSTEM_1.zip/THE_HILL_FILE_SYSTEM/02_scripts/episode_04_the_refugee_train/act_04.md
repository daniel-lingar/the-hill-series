# Episode 4 — The Refugee Train
## Act 4

**Status:** GAP_FROM_REPO_AUDIT__RECOVERED_SPINE_NEEDS_FULL_SCRIPT

## Canonical Spine

RECOVERED SPINE: An armed stop forces the family to decide how much truth is safe. Children watch adults negotiate survival with partial names.

## Script Body

[Place full scene-by-scene script text here. Keep this act inside the five-act structure.]

## Evidence Notes

- Mark historical claims as Proven / Supported / Tradition / Question / Unknown.
- Do not turn tradition into proof.
- Do not write violence as payoff.
