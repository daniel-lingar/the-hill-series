# Episode 5 — Company K
## Act 2

**Status:** GAP_FROM_REPO_AUDIT__RECOVERED_SPINE_NEEDS_FULL_SCRIPT

## Canonical Spine

RECOVERED SPINE: The roster cluster sharpens: Francis, William Riley, Pleasant, Lewis Cass, William Gordon, and John Turner. A family does not have to stand on one line to be targeted as one body.

## Script Body

[Place full scene-by-scene script text here. Keep this act inside the five-act structure.]

## Evidence Notes

- Mark historical claims as Proven / Supported / Tradition / Question / Unknown.
- Do not turn tradition into proof.
- Do not write violence as payoff.
