# Episode 5 — Company K
## Act 4

**Status:** GAP_FROM_REPO_AUDIT__RECOVERED_SPINE_NEEDS_FULL_SCRIPT

## Canonical Spine

RECOVERED SPINE: John Turner wants action, but the file forces discipline. Names are sorted: Jess Wilson, Wash Middleton, Fate Arnold, local men, unknown. Heard is not nothing. Heard is not proof.

## Script Body

[Place full scene-by-scene script text here. Keep this act inside the five-act structure.]

## Evidence Notes

- Mark historical claims as Proven / Supported / Tradition / Question / Unknown.
- Do not turn tradition into proof.
- Do not write violence as payoff.
