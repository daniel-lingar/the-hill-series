# Episode 3 — The Cave
## Act 4

**Status:** GAP_FROM_REPO_AUDIT__RECOVERED_SPINE_NEEDS_FULL_SCRIPT

## Canonical Spine

RECOVERED SPINE: The cost of keeping William alive rises. A water trip nearly exposes the hiding place. Mary Ann refuses to let panic make noise. The cave teaches the children that survival has no clean shape.

## Script Body

[Place full scene-by-scene script text here. Keep this act inside the five-act structure.]

## Evidence Notes

- Mark historical claims as Proven / Supported / Tradition / Question / Unknown.
- Do not turn tradition into proof.
- Do not write violence as payoff.
