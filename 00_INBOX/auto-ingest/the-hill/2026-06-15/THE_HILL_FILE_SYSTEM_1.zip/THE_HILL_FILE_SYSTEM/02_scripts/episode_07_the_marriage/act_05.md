# Episode 7 — The Marriage
## Act 5

**Status:** GAP_FROM_REPO_AUDIT__RECOVERED_SPINE_NEEDS_FULL_SCRIPT

## Canonical Spine

RECOVERED SPINE: The marriage ceremony becomes the structural climax. The record says married; the act shows what it cost. Marriage does not heal the war; it builds a room where the living can continue.

## Script Body

[Place full scene-by-scene script text here. Keep this act inside the five-act structure.]

## Evidence Notes

- Mark historical claims as Proven / Supported / Tradition / Question / Unknown.
- Do not turn tradition into proof.
- Do not write violence as payoff.
