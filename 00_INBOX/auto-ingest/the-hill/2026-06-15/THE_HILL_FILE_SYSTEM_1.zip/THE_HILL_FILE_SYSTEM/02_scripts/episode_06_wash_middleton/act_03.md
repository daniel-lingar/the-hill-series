# Episode 6 — Wash Middleton
## Act 3

**Status:** GAP_FROM_REPO_AUDIT__RECOVERED_SPINE_NEEDS_FULL_SCRIPT

## Canonical Spine

RECOVERED SPINE: Wash and Fate watch the dance house. A soldier says the name too early. Fate nearly draws. Wash stops him: 'We have a maybe in a room full of people.' Not shooting is not nothing.

## Script Body

[Place full scene-by-scene script text here. Keep this act inside the five-act structure.]

## Evidence Notes

- Mark historical claims as Proven / Supported / Tradition / Question / Unknown.
- Do not turn tradition into proof.
- Do not write violence as payoff.
