# THE HILL — Unified File System

This is the single working file system for **THE HILL — Season One**.

Purpose: stop the project from living as scattered chats, posters, notes, and partial drafts. Every episode has a five-act slot. Every gap has a place. Every claim has a lane.

## Operating Rule

The show does not pretend certainty. It separates:

- **Proven**
- **Supported**
- **Tradition**
- **Question**
- **Unknown**

That evidence discipline is part of the story. It is not paperwork sitting outside the story.

## Core Season Line

A modern Arkansas descendant reconstructs an 1864 family killing in the Ozarks and discovers that the real inheritance is not revenge or certainty, but learning how to carry an unresolved story without turning it into a weapon.

## Use This Order

1. Open `00_admin/MASTER_AUDIT_TRACKER.md`.
2. Fix every file marked `GAP` or `RECOVERED_SPINE_NEEDS_FULL_SCRIPT`.
3. Keep all episode scripts under `02_scripts/episode_##_title/`.
4. Keep source rules under `04_evidence/`.
5. Keep poster/image notes under `05_visuals/`.
6. Use `06_pitch_package/` when turning this into a public pitch, deck, or repo landing page.
